"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var path = require('path');
var url = require('url');
var fs = require('fs');
const tl = require("azure-pipelines-task-lib/task");
const WebApi_1 = require("azure-devops-node-api/WebApi");
const BuildInterfaces_1 = require("azure-devops-node-api/interfaces/BuildInterfaces");
const engine = require("artifact-engine/Engine");
const webHandlers = require("artifact-engine/Providers/typed-rest-client/Handlers");
const DownloadHandlerContainer_1 = require("./DownloadHandlers/DownloadHandlerContainer");
const DownloadHandlerContainerZip_1 = require("./DownloadHandlers/DownloadHandlerContainerZip");
const DownloadHandlerFilePath_1 = require("./DownloadHandlers/DownloadHandlerFilePath");
const download_helper_1 = require("./download_helper");
const file_helper_1 = require("./file_helper");
var taskJson = require('./task.json');
tl.setResourcePath(path.join(__dirname, 'task.json'));
const area = 'DownloadBuildArtifacts';
const DefaultParallelProcessingLimit = 8;
function getDefaultProps() {
    var hostType = (tl.getVariable('SYSTEM.HOSTTYPE') || "").toLowerCase();
    return {
        hostType: hostType,
        definitionName: '[NonEmail:' + (hostType === 'release' ? tl.getVariable('RELEASE.DEFINITIONNAME') : tl.getVariable('BUILD.DEFINITIONNAME')) + ']',
        processId: hostType === 'release' ? tl.getVariable('RELEASE.RELEASEID') : tl.getVariable('BUILD.BUILDID'),
        processUrl: hostType === 'release' ? tl.getVariable('RELEASE.RELEASEWEBURL') : (tl.getVariable('SYSTEM.TEAMFOUNDATIONSERVERURI') + tl.getVariable('SYSTEM.TEAMPROJECT') + '/_build?buildId=' + tl.getVariable('BUILD.BUILDID')),
        taskDisplayName: tl.getVariable('TASK.DISPLAYNAME'),
        jobid: tl.getVariable('SYSTEM.JOBID'),
        agentVersion: tl.getVariable('AGENT.VERSION'),
        agentOS: tl.getVariable('AGENT.OS'),
        agentName: tl.getVariable('AGENT.NAME'),
        version: taskJson.version
    };
}
function publishEvent(feature, properties) {
    try {
        var splitVersion = (process.env.AGENT_VERSION || '').split('.');
        var major = parseInt(splitVersion[0] || '0');
        var minor = parseInt(splitVersion[1] || '0');
        let telemetry = '';
        if (major > 2 || (major == 2 && minor >= 120)) {
            telemetry = `##vso[telemetry.publish area=${area};feature=${feature}]${JSON.stringify(Object.assign(getDefaultProps(), properties))}`;
        }
        else {
            if (feature === 'reliability') {
                let reliabilityData = properties;
                telemetry = "##vso[task.logissue type=error;code=" + reliabilityData.issueType + ";agentVersion=" + tl.getVariable('Agent.Version') + ";taskId=" + area + "-" + JSON.stringify(taskJson.version) + ";]" + reliabilityData.errorMessage;
            }
        }
        console.log(telemetry);
        ;
    }
    catch (err) {
        tl.warning("Failed to log telemetry, error: " + err);
    }
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        var promise = new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            var buildType = tl.getInput("buildType", true);
            var isCurrentBuild = buildType.toLowerCase() === 'current';
            var isSpecificBuildWithTriggering = tl.getBoolInput("specificBuildWithTriggering", false);
            var projectId = null;
            var definitionId = null;
            var definitionIdSpecified = null;
            var definitionIdTriggered = null;
            var buildId = null;
            var buildVersionToDownload = tl.getInput("buildVersionToDownload", false);
            var allowPartiallySucceededBuilds = tl.getBoolInput("allowPartiallySucceededBuilds", false);
            var branchName = tl.getInput("branchName", false);
            var downloadPath = path.normalize(tl.getInput("downloadPath", true));
            var cleanDestinationFolder = tl.getBoolInput("cleanDestinationFolder", false);
            var downloadType = tl.getInput("downloadType", true);
            var tagFiltersInput = tl.getInput("tags", false);
            var tagFilters = [];
            if (!!tagFiltersInput) {
                tagFilters = tagFiltersInput.split(",");
            }
            const checkDownloadedFiles = tl.getBoolInput('checkDownloadedFiles', false);
            const shouldExtractTars = tl.getBoolInput('extractTars');
            const isWin = process.platform === 'win32';
            if (shouldExtractTars && isWin) {
                reject(tl.loc('TarExtractionNotSupportedInWindows'));
                return;
            }
            var endpointUrl = tl.getVariable("System.TeamFoundationCollectionUri");
            var accessToken = tl.getEndpointAuthorizationParameter('SYSTEMVSSCONNECTION', 'AccessToken', false);
            var credentialHandler = WebApi_1.getHandlerFromToken(accessToken);
            var webApi = new WebApi_1.WebApi(endpointUrl, credentialHandler);
            const retryLimitRequest = parseInt(tl.getVariable('VSTS_HTTP_RETRY')) ? parseInt(tl.getVariable("VSTS_HTTP_RETRY")) : 4;
            const retryLimitDownload = parseInt(tl.getInput('retryDownloadCount', false)) ? parseInt(tl.getInput('retryDownloadCount', false)) : 4;
            var templatePath = path.join(__dirname, 'vsts.handlebars.txt');
            var buildApi = yield executeWithRetries("getBuildApi", () => webApi.getBuildApi(), retryLimitRequest).catch((reason) => {
                reject(reason);
                return;
            });
            var artifacts = [];
            // Clean destination folder if requested
            if (cleanDestinationFolder) {
                file_helper_1.cleanUpFolder(downloadPath);
            }
            if (isCurrentBuild) {
                projectId = tl.getVariable("System.TeamProjectId");
                definitionId = '';
                buildId = parseInt(tl.getVariable("Build.BuildId"));
            }
            else {
                var releaseAlias = tl.getVariable("release.triggeringartifact.alias");
                var triggeringBuildFound = false;
                definitionIdSpecified = tl.getInput("definition", true);
                if (isSpecificBuildWithTriggering) {
                    let hostType = tl.getVariable('system.hostType');
                    if ((hostType && hostType.toUpperCase() != 'BUILD')) {
                        // try to use alias to grab triggering artifact for release, starting with definition to verify parity with specified definition
                        definitionIdTriggered = tl.getVariable("release.artifacts." + releaseAlias + ".definitionId");
                        if (definitionIdTriggered == definitionIdSpecified) {
                            // populate values using the triggering build
                            projectId = tl.getVariable("release.artifacts." + releaseAlias + ".projectId");
                            definitionId = definitionIdTriggered;
                            buildId = parseInt(tl.getVariable("release.artifacts." + releaseAlias + ".buildId"));
                            // verify that the triggerring bruild's info was found
                            if (projectId && definitionId && buildId) {
                                triggeringBuildFound = true;
                            }
                        }
                    }
                    else {
                        //Verify that the triggering build's definition is the same as the specified definition
                        definitionIdTriggered = tl.getVariable("build.triggeredBy.definitionId");
                        if (definitionIdTriggered == definitionIdSpecified) {
                            // populate values using the triggering build
                            projectId = tl.getVariable("build.triggeredBy.projectId");
                            definitionId = definitionIdTriggered;
                            buildId = parseInt(tl.getVariable("build.triggeredBy.buildId"));
                            // verify that the triggerring bruild's info was found
                            if (projectId && definitionId && buildId) {
                                triggeringBuildFound = true;
                            }
                        }
                    }
                }
                if (!triggeringBuildFound) {
                    // Triggering build info not found, or requested, default to specified build info
                    projectId = tl.getInput("project", true);
                    definitionId = definitionIdSpecified;
                    buildId = parseInt(tl.getInput("buildId", buildVersionToDownload == "specific"));
                }
                // if the definition name includes a variable then definitionIdSpecified is a name vs a number
                if (!!definitionIdSpecified && Number.isNaN(parseInt(definitionIdSpecified))) {
                    var definitions = yield executeWithRetries("getBuildDefinitions", () => buildApi.getDefinitions(projectId, definitionIdSpecified), retryLimitRequest).catch((reason) => {
                        reject(reason);
                        return;
                    });
                    if (!definitions || definitions.length < 1) {
                        reject(tl.loc("InvalidBuildDefinitionName", definitionIdSpecified));
                        return;
                    }
                    definitionId = String(definitions[0].id);
                    console.log(tl.loc("DefinitionNameMatchFound", definitionIdSpecified, definitionId));
                }
                if (!definitionId) {
                    reject(tl.loc("UnresolvedDefinitionId"));
                    return;
                }
            }
            // verify that buildId belongs to the definition selected
            if (definitionId) {
                var build;
                if (buildVersionToDownload != "specific" && !triggeringBuildFound) {
                    var resultFilter = BuildInterfaces_1.BuildResult.Succeeded;
                    if (allowPartiallySucceededBuilds) {
                        resultFilter |= BuildInterfaces_1.BuildResult.PartiallySucceeded;
                    }
                    var branchNameFilter = (buildVersionToDownload == "latest") ? null : branchName;
                    // get latest successful build filtered by branch
                    var buildsForThisDefinition = yield executeWithRetries("getBuildId", () => buildApi.getBuilds(projectId, [parseInt(definitionId)], null, null, null, null, null, null, BuildInterfaces_1.BuildStatus.Completed, resultFilter, tagFilters, null, null, null, null, null, BuildInterfaces_1.BuildQueryOrder.FinishTimeDescending, branchNameFilter), retryLimitRequest).catch((reason) => {
                        reject(reason);
                        return;
                    });
                    if (!buildsForThisDefinition || buildsForThisDefinition.length == 0) {
                        if (buildVersionToDownload == "latestFromBranch")
                            reject(tl.loc("LatestBuildFromBranchNotFound", branchNameFilter));
                        else
                            reject(tl.loc("LatestBuildNotFound"));
                        return;
                    }
                    build = buildsForThisDefinition[0];
                    console.log(tl.loc("LatestBuildFound", build.id));
                    buildId = build.id;
                }
                if (!build) {
                    build = yield executeWithRetries("getBuild", () => buildApi.getBuild(projectId, buildId), retryLimitRequest).catch((reason) => {
                        reject(reason);
                        return;
                    });
                }
                if (build) {
                    if (!build.definition || build.definition.id !== parseInt(definitionId)) {
                        reject(tl.loc("BuildIdBuildDefinitionMismatch", buildId, definitionId));
                        return;
                    }
                }
                else {
                    reject(tl.loc("BuildNotFound", buildId));
                    return;
                }
            }
            console.log(tl.loc("DownloadingArtifactsForBuild", buildId));
            // populate output variable 'BuildNumber' with buildId
            tl.setVariable('BuildNumber', buildId.toString());
            // populate itempattern and artifacts based on downloadType
            if (downloadType === 'single') {
                var artifactName = tl.getInput("artifactName", true);
                // if FF EnableBuildArtifactsPlusSignWorkaround is enabled or AZP_TASK_FF_ENABLE_BUILDARTIFACTS_PLUS_SIGN_WORKAROUND environment variable is set:
                // replacing '+' symbol by its representation ' '(space) - workaround for the DownloadBuildArtifactV0 task,
                // where downloading of part of artifact is not possible if there is a plus symbol
                const enableBuildArtifactsPlusSignWorkaround = process.env.AZP_TASK_FF_ENABLE_BUILDARTIFACTS_PLUS_SIGN_WORKAROUND ? process.env.AZP_TASK_FF_ENABLE_BUILDARTIFACTS_PLUS_SIGN_WORKAROUND.toLowerCase() === "true" : false;
                if (enableBuildArtifactsPlusSignWorkaround)
                    artifactName = artifactName.replace(/\+/g, ' ');
                var artifact = yield executeWithRetries("getArtifact", () => buildApi.getArtifact(projectId, buildId, artifactName), retryLimitRequest).catch((reason) => {
                    reject(reason);
                    return;
                });
                if (!artifact) {
                    reject(tl.loc("BuildArtifactNotFound", artifactName, buildId));
                    return;
                }
                artifacts.push(artifact);
            }
            else {
                var buildArtifacts = yield executeWithRetries("getArtifacts", () => buildApi.getArtifacts(projectId, buildId), retryLimitRequest).catch((reason) => {
                    reject(reason);
                });
                if (!buildArtifacts) {
                    tl.warning(tl.loc("NoArtifactsFound", buildId));
                    resolve();
                    return;
                }
                console.log(tl.loc("LinkedArtifactCount", buildArtifacts.length));
                artifacts = artifacts.concat(buildArtifacts);
            }
            if (artifacts) {
                var downloadPromises = [];
                artifacts.forEach(function (artifact, index, artifacts) {
                    return __awaiter(this, void 0, void 0, function* () {
                        const downloaderOptions = configureDownloaderOptions();
                        const config = {
                            artifactInfo: artifact,
                            downloadPath: downloadPath,
                            downloaderOptions: downloaderOptions,
                            checkDownloadedFiles: checkDownloadedFiles
                        };
                        if (artifact.resource.type.toLowerCase() === "container") {
                            var handler = new webHandlers.PersonalAccessTokenCredentialHandler(accessToken);
                            // this variable uses to force enable zip download option, it is used only in test purpose and shouldn't be used for other reasons
                            const forceEnableZipDownloadOption = tl.getVariable("DownloadBuildArtifacts.ForceEnableDownloadZipForCanary");
                            const forceEnableZipDownloadOptionBool = forceEnableZipDownloadOption ? forceEnableZipDownloadOption.toLowerCase() == 'true' : false;
                            var isPullRequestFork = tl.getVariable("SYSTEM.PULLREQUEST.ISFORK");
                            var isPullRequestForkBool = isPullRequestFork ? isPullRequestFork.toLowerCase() == 'true' : false;
                            var isZipDownloadDisabled = tl.getVariable("SYSTEM.DisableZipDownload");
                            var isZipDownloadDisabledBool = isZipDownloadDisabled ? isZipDownloadDisabled.toLowerCase() != 'false' : false;
                            // Disable zip download if selective itemPattern provided
                            if (downloaderOptions.itemPattern !== "**") {
                                isZipDownloadDisabledBool = true;
                            }
                            if (isWin && ((!isZipDownloadDisabledBool && isPullRequestForkBool) || forceEnableZipDownloadOptionBool)) {
                                const operationName = `Download zip - ${artifact.name}`;
                                const handlerConfig = Object.assign(Object.assign({}, config), { projectId, buildId, handler, endpointUrl });
                                const downloadHandler = new DownloadHandlerContainerZip_1.DownloadHandlerContainerZip(handlerConfig);
                                const downloadPromise = executeWithRetries(operationName, () => downloadHandler.downloadResources(), retryLimitDownload).catch((reason) => {
                                    reject(reason);
                                    return;
                                });
                                downloadPromises.push(downloadPromise);
                                yield downloadPromise;
                            }
                            else {
                                const operationName = `Download container - ${artifact.name}`;
                                const handlerConfig = Object.assign(Object.assign({}, config), { endpointUrl, templatePath, handler });
                                const downloadHandler = new DownloadHandlerContainer_1.DownloadHandlerContainer(handlerConfig);
                                const downloadPromise = executeWithRetries(operationName, () => downloadHandler.downloadResources(), retryLimitDownload).catch((reason) => {
                                    reject(reason);
                                    return;
                                });
                                downloadPromises.push(downloadPromise);
                                yield downloadPromise;
                            }
                        }
                        else if (artifact.resource.type.toLowerCase() === "filepath") {
                            const operationName = `Download by FilePath - ${artifact.name}`;
                            const downloadHandler = new DownloadHandlerFilePath_1.DownloadHandlerFilePath(config);
                            const downloadPromise = executeWithRetries(operationName, () => downloadHandler.downloadResources(), retryLimitDownload).catch((reason) => {
                                reject(reason);
                                return;
                            });
                            downloadPromises.push(downloadPromise);
                            yield downloadPromise;
                        }
                        else {
                            console.log(tl.loc("UnsupportedArtifactType", artifact.resource.type));
                        }
                    });
                });
                Promise.all(downloadPromises).then((tickets) => {
                    console.log(tl.loc('ArtifactsSuccessfullyDownloaded', downloadPath));
                    if (shouldExtractTars) {
                        file_helper_1.extractTarsIfPresent(tickets, downloadPath);
                    }
                    resolve();
                }).catch((error) => {
                    reject(error);
                });
            }
        }));
        return promise;
    });
}
function executeWithRetries(operationName, operation, retryCount) {
    var executePromise = new Promise((resolve, reject) => {
        executeWithRetriesImplementation(operationName, operation, retryCount, resolve, reject, retryCount);
    });
    return executePromise;
}
function executeWithRetriesImplementation(operationName, operation, currentRetryCount, resolve, reject, retryCountLimit) {
    operation().then((result) => {
        resolve(result);
    }).catch((error) => {
        if (currentRetryCount <= 0) {
            tl.error(tl.loc("OperationFailed", operationName, error));
            reject(error);
        }
        else {
            console.log(tl.loc('RetryingOperation', operationName, currentRetryCount));
            currentRetryCount = currentRetryCount - 1;
            setTimeout(() => executeWithRetriesImplementation(operationName, operation, currentRetryCount, resolve, reject, retryCountLimit), getRetryIntervalInSeconds(retryCountLimit - currentRetryCount) * 1000);
        }
    });
}
function getRetryIntervalInSeconds(retryCount) {
    let MaxRetryLimitInSeconds = 360;
    let baseRetryIntervalInSeconds = 5;
    var exponentialBackOff = baseRetryIntervalInSeconds * Math.pow(3, (retryCount + 1));
    return exponentialBackOff < MaxRetryLimitInSeconds ? exponentialBackOff : MaxRetryLimitInSeconds;
}
function configureDownloaderOptions() {
    const downloaderOptions = new engine.ArtifactEngineOptions();
    const debugMode = tl.getVariable('System.Debug');
    downloaderOptions.verbose = debugMode ? debugMode.toLowerCase() !== 'false' : false;
    const artifactDownloadLimit = tl.getVariable('release.artifact.download.parallellimit');
    const taskInputParallelLimit = tl.getInput('parallelizationLimit', false);
    downloaderOptions.parallelProcessingLimit = download_helper_1.resolveParallelProcessingLimit(artifactDownloadLimit, taskInputParallelLimit, DefaultParallelProcessingLimit);
    downloaderOptions.itemPattern = tl.getInput('itemPattern', false) || '**';
    return downloaderOptions;
}
main()
    .then((result) => tl.setResult(tl.TaskResult.Succeeded, ""))
    .catch((err) => {
    publishEvent('reliability', { issueType: 'error', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
    tl.setResult(tl.TaskResult.Failed, err);
});
