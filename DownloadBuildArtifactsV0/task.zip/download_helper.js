"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveParallelProcessingLimit = exports.handlerCheckDownloadedFiles = void 0;
const task_1 = require("azure-pipelines-task-lib/task");
const Models_1 = require("artifact-engine/Models");
const file_helper_1 = require("./file_helper");
/**
 * This function checks a result of artifact download
 * @param  {Array<ArtifactDownloadTicket>} downloadTickets
 * @throws Exception if downloaded build artifact is not healthy
 * @returns void
 */
function handlerCheckDownloadedFiles(downloadTickets) {
    console.log(task_1.loc('BeginArtifactItemsIntegrityCheck'));
    task_1.debug(`Items count: ${downloadTickets.length}`);
    const corruptedItems = downloadTickets.filter(ticket => isItemCorrupted(ticket));
    if (corruptedItems.length > 0) {
        console.log(task_1.loc('CorruptedArtifactItemsList'));
        corruptedItems.map(item => console.log(item.artifactItem.metadata.destinationUrl));
        throw new Error(task_1.loc('IntegrityCheckNotPassed'));
    }
    console.log(task_1.loc('IntegrityCheckPassed'));
}
exports.handlerCheckDownloadedFiles = handlerCheckDownloadedFiles;
/**
 * This function investigates the download ticket of the artifact item.
 *
 * Since artifact's items stored as compressed files the only appropriate way (at the moment)
 * to make sure that the item fully downloaded is to compare bytes length before compress
 * that provided by Azure DevOps and actual bytes length from local storage.
 *
 * @param  {ArtifactDownloadTicket} ticket - download ticket of artifact item
 * @returns {boolean} `true` if item corrupted, `false` if item healthy
 */
function isItemCorrupted(ticket) {
    let isCorrupted = false;
    // We check the tickets only with processed status and File item type
    if (ticket.state === Models_1.TicketState.Processed &&
        ticket.artifactItem.itemType === Models_1.ItemType.File) {
        task_1.debug(`Start check for item: ${ticket.artifactItem.path}`);
        task_1.debug(`Getting info from download ticket`);
        const localPathToFile = ticket.artifactItem.metadata.destinationUrl;
        task_1.debug(`Local path to the item: ${localPathToFile}`);
        if (ticket.artifactItem.fileLength) {
            const expectedBytesLength = Number(ticket.artifactItem.fileLength);
            if (isNaN(expectedBytesLength)) {
                task_1.debug('Incorrect data in related download ticket, skip item validation.');
                isCorrupted = true;
            }
            else {
                task_1.debug(`Expected length in bytes ${expectedBytesLength}`);
                try {
                    const actualBytesLength = file_helper_1.getFileSizeInBytes(localPathToFile);
                    task_1.debug(`Actual length in bytes ${actualBytesLength}`);
                    isCorrupted = (expectedBytesLength !== actualBytesLength);
                }
                catch (error) {
                    task_1.debug('Unable to get file stats from local storage due to the following error:');
                    task_1.debug(error);
                    task_1.debug('Skip item validation');
                    isCorrupted = true;
                }
            }
        }
        else if (ticket.artifactItem.metadata.downloadUrl.endsWith('format=zip')) {
            // When we use a Zip Provider the Artifact Engine returns only "fileSizeInBytes"
            try {
                const expectedBytesLength = Number(ticket.fileSizeInBytes);
                const actualBytesLength = file_helper_1.getFileSizeInBytes(localPathToFile);
                task_1.debug(`Expected length in bytes ${expectedBytesLength}`);
                task_1.debug(`Actual length in bytes ${actualBytesLength}`);
                return (expectedBytesLength !== actualBytesLength);
            }
            catch (error) {
                task_1.debug('Unable to get file stats from local storage due to the following error:');
                task_1.debug(error);
                task_1.debug('Skip item validation');
                isCorrupted = true;
            }
        }
    }
    return isCorrupted;
}
/**
 * This function resolves the value for the `parallelProcessingLimit` option of `ArtifactEngine`
 *
 * Earlier the only way to set parallelProcessingLimit in the task
 * was by declaring the `release.artifact.download.parallellimit` variable.
 *
 * To maintain backward compatibility we will use the following strategy:
 *
 * Firstly, investigate the `release.artifact.download.parallellimit` variable.
 * If everything is okay with this variable, the task will use the value from this variable.
 *
 * Secondly, investigate the `Parallelization limit` input of the task.
 * If everything is okay with the value in the related task's input, the task will use the value from this input.
 *
 * If validation failed for both cases the function will return the `defaultLimit` for the `parallelProcessingLimit` option.
 *
 * @param {string} artifactDownloadLimit - value of `release.artifact.download.parallellimit` variable
 * @param {string} taskLimit - value of `Parallelization limit` task input
 * @param {number} defaultLimit - the default value that will be returned if `artifactDownloadLimit` and `taskLimit` contain invalid values.
 * @returns {number} - parallel processing limit
 */
function resolveParallelProcessingLimit(artifactDownloadLimit, taskLimit, defaultLimit) {
    task_1.debug(`Checking value of the "release.artifact.download.parallellimit" variable - ${artifactDownloadLimit}`);
    const artifactDownloadParallelLimit = Number(artifactDownloadLimit);
    if (isParallelProcessingLimitCorrect(artifactDownloadParallelLimit)) {
        return artifactDownloadParallelLimit;
    }
    task_1.debug(`Checking value of the "Parallelization limit" input - ${taskLimit}`);
    const taskInputParallelLimit = Number(taskLimit);
    if (isParallelProcessingLimitCorrect(taskInputParallelLimit)) {
        return taskInputParallelLimit;
    }
    task_1.debug(`The parallelization limit is set to default value - ${defaultLimit}`);
    return defaultLimit;
}
exports.resolveParallelProcessingLimit = resolveParallelProcessingLimit;
/**
 * This function checks the input value for the `parallelProcessingLimit` option of `ArtifactEngine`
 *
 * The parallel processing limit must be a number greater than 0.
 *
 * @param {number} limit - value of parallel processing limit
 * @returns {boolean} true if parallel processing limit is correct, false otherwise.
 */
function isParallelProcessingLimitCorrect(limit) {
    const isCorrect = (!isNaN(limit) && limit > 0);
    if (isCorrect) {
        task_1.debug(`The value is correct, the parallelization limit is set to ${limit}`);
    }
    else {
        task_1.debug(`The value is incorrect ${limit}`);
    }
    return isCorrect;
}
