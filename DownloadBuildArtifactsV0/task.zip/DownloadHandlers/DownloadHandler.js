"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadHandler = void 0;
const download_helper_1 = require("../download_helper");
const Engine_1 = require("artifact-engine/Engine");
/**
 * Base class for artifact download handlers
 */
class DownloadHandler {
    constructor(handlerConfig) {
        this.config = handlerConfig;
    }
    /**
     * Method to download Build Artifact.
     * Since the logic for downloading builds artifacts is the same for all
     * types of source and destination providers, we will implement this logic in the base class.
     * @access public
     * @returns {Promise<Array<ArtifactDownloadTicket>>} an array of Download Tickets
    */
    downloadResources() {
        return __awaiter(this, void 0, void 0, function* () {
            const downloader = new Engine_1.ArtifactEngine();
            const sourceProvider = this.getSourceProvider();
            const destinationProvider = this.getDestinationProvider();
            const downloadPromise = new Promise((downloadComplete, downloadFailed) => __awaiter(this, void 0, void 0, function* () {
                try {
                    // First attempt to download artifact
                    const downloadTickets = yield downloader.processItems(sourceProvider, destinationProvider, this.config.downloaderOptions);
                    // We will proceed with the files check only if the "Check download files" option enabled
                    if (this.config.checkDownloadedFiles && Array.isArray(downloadTickets)) {
                        try {
                            // Launch the files check, if all files are fully downloaded no exceptions will be thrown.
                            download_helper_1.handlerCheckDownloadedFiles(downloadTickets);
                            downloadComplete(downloadTickets);
                        }
                        catch (error) {
                            downloadFailed(error);
                        }
                    }
                    else {
                        downloadComplete(downloadTickets);
                    }
                }
                catch (error) {
                    downloadFailed(error);
                }
            }));
            return downloadPromise;
        });
    }
}
exports.DownloadHandler = DownloadHandler;
