"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadHandlerContainerZip = void 0;
const DownloadHandler_1 = require("./DownloadHandler");
const Providers_1 = require("artifact-engine/Providers");
const tl = require("azure-pipelines-task-lib/task");
const path = require("path");
const DecompressZip = require("decompress-zip");
/**
 * Handler for download artifact via build API
 * Build Artifact will be downloaded as zip archive via `/_apis/build/builds/` resource.
 * This handler was designed to work only on windows system.
 * @extends DownloadHandler
 * @example
 * const config: IContainerHandlerZipConfig = {...};
 * const downloadHandler: DownloadHandlerContainerZip = new DownloadHandlerContainerZip(config);
 * downloadHandler.downloadResources();
 */
class DownloadHandlerContainerZip extends DownloadHandler_1.DownloadHandler {
    constructor(handlerConfig) {
        super(handlerConfig);
        this.archiveUrl = `${this.config.endpointUrl}/${this.config.projectId}/_apis/build/builds/${this.config.buildId}/artifacts?artifactName=${encodeURIComponent(this.config.artifactInfo.name)}&$format=zip`;
        this.zipLocation = path.join(this.config.downloadPath, `${this.config.artifactInfo.name}.zip`);
    }
    /**
     * Unpack an archive with an artifact
     * @param unzipLocation path to the target artifact
     * @access private
     * @returns {Promise<void>} promise that will be resolved once the archive will be unpacked
    */
    unzipContainer(unzipLocation) {
        const unZipPromise = new Promise((resolve, reject) => {
            if (!tl.exist(this.zipLocation)) {
                return resolve();
            }
            tl.debug(`Extracting ${this.zipLocation} to ${unzipLocation}`);
            const unzipper = new DecompressZip(this.zipLocation);
            unzipper.on('error', err => {
                return reject(tl.loc('ExtractionFailed', err));
            });
            unzipper.on('extract', log => {
                tl.debug(`Extracted ${this.zipLocation} to ${unzipLocation} successfully`);
                return resolve();
            });
            unzipper.extract({
                path: unzipLocation
            });
        });
        return unZipPromise;
    }
    /**
     * Get zip provider.
     * Since we will download archived artifact we will use `ZipProvider` as source provider.
     * @access protected
     * @returns {ZipProvider} Configured Zip Provider
    */
    getSourceProvider() {
        console.log(tl.loc('DownloadArtifacts', this.config.artifactInfo.name, this.archiveUrl));
        const provider = new Providers_1.ZipProvider(this.archiveUrl, this.config.handler);
        return provider;
    }
    /**
     * Get filesystem provider.
     * Since we download artifact to local storage we will use a `FilesystemProvider` as destination provider.
     * @access protected
     * @returns {FilesystemProvider} Configured Filesystem Provider
    */
    getDestinationProvider() {
        const provider = new Providers_1.FilesystemProvider(this.zipLocation);
        return provider;
    }
    /**
     * Download and unpack an archive with an artifact.
     * @access public
    */
    downloadResources() {
        const downloadProcess = new Promise((resolve, reject) => {
            tl.debug('Starting downloadZip action');
            if (tl.exist(this.zipLocation)) {
                tl.rmRF(this.zipLocation);
            }
            super.downloadResources().then(() => {
                tl.debug(`Successfully downloaded from ${this.archiveUrl}`);
                this.unzipContainer(this.config.downloadPath).then(() => {
                    tl.debug(`Successfully extracted ${this.zipLocation}`);
                    if (tl.exist(this.zipLocation)) {
                        tl.rmRF(this.zipLocation);
                    }
                    resolve();
                }).catch((error) => {
                    reject(error);
                });
            }).catch((error) => {
                reject(error);
            });
        });
        return downloadProcess;
    }
}
exports.DownloadHandlerContainerZip = DownloadHandlerContainerZip;
