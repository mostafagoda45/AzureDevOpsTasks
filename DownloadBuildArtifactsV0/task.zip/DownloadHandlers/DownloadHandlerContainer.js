"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadHandlerContainer = void 0;
const DownloadHandler_1 = require("./DownloadHandler");
const Providers_1 = require("artifact-engine/Providers");
const tl = require("azure-pipelines-task-lib/task");
/**
 * Handler for download artifact from related container resource.
 * Build Artifact will be downloaded via `_apis/resources/Containers/` resource.
 * @extends DownloadHandler
 * @example
 * const config: IContainerHandlerConfig = {...};
 * const downloadHandler: IContainerHandlerConfig = new IContainerHandlerConfig(config);
 * downloadHandler.downloadResources();
 */
class DownloadHandlerContainer extends DownloadHandler_1.DownloadHandler {
    constructor(handlerConfig) {
        super(handlerConfig);
    }
    /**
     * To download artifact from container resource we will use `WebProvider` as source provider
     * @access protected
     * @returns {WebProvider} Configured Web Provider
    */
    getSourceProvider() {
        console.log(tl.loc('DownloadingContainerResource', this.config.artifactInfo.resource.data));
        const containerParts = this.config.artifactInfo.resource.data.split('/');
        if (containerParts.length < 3) {
            throw new Error(tl.loc('FileContainerInvalidArtifactData'));
        }
        const containerId = parseInt(containerParts[1]);
        let containerPath = containerParts.slice(2, containerParts.length).join('/');
        if (containerPath === '/') {
            //container REST api oddity. Passing '/' as itemPath downloads the first file instead of returning the meta data about the all the files in the root level.
            //This happens only if the first item is a file.
            containerPath = '';
        }
        const variables = {};
        const itemsUrl = `${this.config.endpointUrl}/_apis/resources/Containers/${containerId}?itemPath=${encodeURIComponent(containerPath)}&isShallow=true&api-version=4.1-preview.4`;
        console.log(tl.loc('DownloadArtifacts', this.config.artifactInfo.name, itemsUrl));
        const provider = new Providers_1.WebProvider(itemsUrl, this.config.templatePath, variables, this.config.handler);
        return provider;
    }
    /**
     * Since we download artifact to local storage we will use a `FilesystemProvider` as destination provider
     * @access protected
     * @returns {FilesystemProvider} Configured Filesystem Provider
    */
    getDestinationProvider() {
        const provider = new Providers_1.FilesystemProvider(this.config.downloadPath);
        return provider;
    }
}
exports.DownloadHandlerContainer = DownloadHandlerContainer;
