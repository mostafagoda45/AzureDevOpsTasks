"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadHandlerFilePath = void 0;
const DownloadHandler_1 = require("./DownloadHandler");
const Providers_1 = require("artifact-engine/Providers");
const tl = require("azure-pipelines-task-lib/task");
const fs = require("fs");
const path = require("path");
/**
 * Handler for download artifact via local file share
 * @extends DownloadHandler
 * @example
 * const config: IBaseHandlerConfig = {...};
 * const downloadHandler: DownloadHandlerFilePath = new DownloadHandlerFilePath(config);
 * downloadHandler.downloadResources();
 */
class DownloadHandlerFilePath extends DownloadHandler_1.DownloadHandler {
    /**
     * Get source provider with source folder.
     * Since we will work with local files we use `Filesystem Provider` as source provider.
     * @access protected
     * @returns {FilesystemProvider} Configured Filesystem Provider
     */
    getSourceProvider() {
        const downloadUrl = this.config.artifactInfo.resource.data;
        const artifactName = this.config.artifactInfo.name.replace('/', '\\');
        let artifactLocation = path.join(downloadUrl, artifactName);
        console.log(tl.loc('DownloadArtifacts', artifactName, artifactLocation));
        if (!fs.existsSync(artifactLocation)) {
            console.log(tl.loc('ArtifactNameDirectoryNotFound', artifactLocation, downloadUrl));
            artifactLocation = downloadUrl;
        }
        const provider = new Providers_1.FilesystemProvider(artifactLocation, artifactName);
        return provider;
    }
    /**
     * Get destination provider with destination folder.
     * Since we will work with local files we use `Filesystem Provider` as source provider.
     * @access protected
     * @returns {FilesystemProvider} Configured Filesystem Provider
     */
    getDestinationProvider() {
        const provider = new Providers_1.FilesystemProvider(this.config.downloadPath);
        return provider;
    }
}
exports.DownloadHandlerFilePath = DownloadHandlerFilePath;
